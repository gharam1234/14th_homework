"use client";

import BoardsWrite from '@/components/boards-write';


export default function BoardsNew() {

  return (
     <BoardsWrite isEdit={false} />
  )
}



