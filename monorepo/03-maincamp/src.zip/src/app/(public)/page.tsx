"use client"

import LoginHome from "@/components/login/login-home"


export default function LoginPage(){
    return(
        <>  
            <LoginHome />
        </>
    )
}