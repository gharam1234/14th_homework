"use client"

import SignUp from "@/components/login/signup"




export default function signUpPage(){
    return(
        <>  
            <SignUp />
        </>
    )
}