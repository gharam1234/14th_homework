import CardGame from "@/components/openapis-list";

export default function CardGamePage(){

    return(
        <>
        <CardGame/>
        </>
    )
}