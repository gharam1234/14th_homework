"use client"
import UtubeNew from "@/components/myapis-new"


export default function UtubeNewPage(){
   

    return (
        <UtubeNew/>
    )
}
