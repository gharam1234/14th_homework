"use client"

import UtubeList from "@/components/myapis-list"




export default function UtubeListPage(){

    return(
        <UtubeList/>
    )
}
