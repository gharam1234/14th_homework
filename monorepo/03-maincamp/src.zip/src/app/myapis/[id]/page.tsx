"use client"
import UtubeDetail from "@/components/myapis-detail"



export default function UtubeDetailPage(){
   

    return(
        <UtubeDetail/>
    )
}
