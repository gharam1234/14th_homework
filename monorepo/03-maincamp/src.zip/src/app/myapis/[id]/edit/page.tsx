"use client"
import UtubeEdit from "@/components/myapis-edit"




export default function UtubeEditPage(){

    return(
        <UtubeEdit/>
    )
}
