
export interface IProps {
  children: React.ReactNode;
}