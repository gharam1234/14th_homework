
export interface Idata {
    title : string;
    url : string;
    created_at : string;
    id : string;
    }
    